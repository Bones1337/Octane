# NovaNuker

NovaNuker is a powerful and brutal account nuker for Discord accounts made in C# with the help of the Anarchy wrapper.
This nuker is really faster and powerful so if you do not want to waste your time to wait the account getting nuked, use this. Enjoy :)
